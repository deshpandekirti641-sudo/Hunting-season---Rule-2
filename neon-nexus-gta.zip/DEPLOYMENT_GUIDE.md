# Neon Nexus City - GTA5 Clone Deployment Guide

## Project Overview
**Neon Nexus City** is a mini GTA5-like game built with Next.js 16, Three.js, and Tailwind CSS v4. It features aggressive action gameplay with NPCs, vehicles, combat, and a wanted level system.

## Project Structure
\`\`\`
neon-nexus-gta/
├── app/
│   ├── page.tsx              # Main game component
│   ├── layout.tsx            # Root layout
│   └── globals.css           # Global styles
├── components/
│   ├── game-hud.tsx          # HUD display
│   ├── game-menu.tsx         # Game menu
│   └── ui/                   # shadcn/ui components
├── public/                   # Static assets
├── .github/
│   └── workflows/
│       └── deploy.yml        # GitHub Actions workflow
├── package.json              # Dependencies
├── tsconfig.json             # TypeScript config
├── next.config.mjs           # Next.js config
├── postcss.config.mjs        # PostCSS config
└── tailwind.config.js        # Tailwind config
\`\`\`

## Pre-Deployment Cleanup (CRITICAL FOR SUCCESS)

### Step 1: Clean Installation (Choose Your OS)

**Linux/macOS:**
\`\`\`bash
# Remove all node_modules and lock files
rm -rf node_modules package-lock.json yarn.lock

# Clear npm cache completely
npm cache clean --force

# Verify Node.js and npm versions
echo "Node.js version:"
node -v    # Should be v20.x or higher
echo "npm version:"
npm -v     # Should be v10.x or higher

# Fresh install
npm install

# Verify build works
npm run build
\`\`\`

**Windows (Command Prompt):**
\`\`\`batch
# Remove all node_modules and lock files
rmdir /s /q node_modules
del /q package-lock.json
del /q yarn.lock

# Clear npm cache completely
npm cache clean --force

# Verify Node.js and npm versions
echo Node.js version:
node -v    # Should be v20.x or higher
echo npm version:
npm -v     # Should be v10.x or higher

# Fresh install
npm install

# Verify build works
npm run build
\`\`\`

## Local Development

### Prerequisites
- Node.js 20.x or higher
- npm or bun package manager

### Installation
\`\`\`bash
# Clone the repository
git clone <your-repo-url>
cd neon-nexus-gta

# Run clean installation (see Pre-Deployment Cleanup above)
npm install
\`\`\`

### Running Locally
\`\`\`bash
# Start development server
npm run dev
# or
bun run dev

# Open http://localhost:3000 in your browser
\`\`\`

### Building for Production
\`\`\`bash
# Build the project
npm run build

# Start production server
npm start
\`\`\`

## Deployment to Vercel

### Prerequisites
1. Vercel account (https://vercel.com)
2. GitHub repository with the project
3. GitHub personal access token

### Step 1: Connect GitHub Repository
1. Go to https://vercel.com/new
2. Click "Import Git Repository"
3. Select your GitHub repository
4. Click "Import"

### Step 2: Configure Environment Variables
In Vercel dashboard:
1. Go to Settings → Environment Variables
2. No special environment variables needed for this project
3. Click "Save"

### Step 3: Deploy
1. Click "Deploy"
2. Wait for build to complete (usually 2-3 minutes)
3. Your game will be live at \`https://<project-name>.vercel.app\`

### Step 4: Set Up GitHub Actions (Optional)
For automatic deployments on push:

1. Add Vercel secrets to GitHub:
   - Go to GitHub repository → Settings → Secrets and variables → Actions
   - Add these secrets:
     - \`VERCEL_TOKEN\`: Your Vercel API token (from https://vercel.com/account/tokens)
     - \`VERCEL_ORG_ID\`: Your Vercel organization ID
     - \`VERCEL_PROJECT_ID\`: Your Vercel project ID

2. The \`.github/workflows/deploy.yml\` file will automatically deploy on push to main branch

## Troubleshooting

### Build Errors

**Error: Cannot find module '@tailwindcss/postcss'**
- Solution: Ensure \`@tailwindcss/postcss\` is in devDependencies
- Run: \`npm install --save-dev @tailwindcss/postcss\`

**Error: PCFShadowShadowMap doesn't exist**
- Solution: Use \`PCFShadowMap\` instead (already fixed in current version)

**Error: package.json not found**
- Solution: Ensure package.json is in the root directory, not in /src/

**npm install fails:**
- Run clean installation commands above
- Delete .next folder: \`rm -rf .next\`
- Clear npm cache: \`npm cache clean --force\`
- Reinstall: \`npm install\`

### Performance Issues

**Game runs slowly**
- Reduce NPC count in \`app/page.tsx\` (currently 12)
- Disable shadows: Set \`renderer.shadowMap.enabled = false\`
- Reduce particle count in \`createParticles()\` function

**High memory usage**
- Clear browser cache
- Close other tabs
- Reduce map size or NPC count

## Game Controls

| Key | Action |
|-----|--------|
| W/A/S/D | Move |
| Shift | Sprint |
| Space | Jump |
| E | Enter/Exit Vehicle |
| C | Toggle Camera (1st/3rd person) |
| 1/2/3 | Switch Weapons |
| Click | Shoot |
| M | Skip Mission |
| ESC | Pause Menu |

## Features

- **3D Game Engine**: Built with Three.js for immersive graphics
- **Aggressive NPCs**: 12 enemies with AI, boss enemies with higher health
- **Vehicle System**: 4 drivable cars with physics
- **Combat System**: 3 weapon types (pistol, rifle, shotgun)
- **Particle Effects**: Blood, smoke, and spark effects
- **Sound Effects**: Web Audio API for dynamic sound generation
- **Wanted Level**: Police threat system
- **Mission System**: Elimination, delivery, and survival missions
- **HUD Display**: Real-time stats, health, ammo, money tracking

## Performance Optimization

### Recommended Settings for Deployment
- Vercel Pro plan for better performance
- Enable Vercel Analytics for monitoring
- Use CDN for static assets

### Build Optimization
- Next.js 16 with Turbopack (default)
- Automatic code splitting
- Image optimization enabled
- CSS minification with Tailwind v4

## Support & Resources

- **Next.js Docs**: https://nextjs.org/docs
- **Three.js Docs**: https://threejs.org/docs
- **Vercel Docs**: https://vercel.com/docs
- **Tailwind CSS**: https://tailwindcss.com/docs

## License
MIT License - Feel free to use and modify

---

**Last Updated**: October 26, 2025
**Version**: 1.0.0
\`\`\`
