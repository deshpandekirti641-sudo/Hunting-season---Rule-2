# Quick Deployment Commands

## Clean Installation (Recommended Before Any Deployment)

### For Linux/macOS:
\`\`\`bash
# Remove all node_modules and lock files
rm -rf node_modules package-lock.json yarn.lock

# Clear npm cache completely
npm cache clean --force

# Verify versions
node -v    # Should be v20.x or higher
npm -v     # Should be v10.x or higher

# Fresh install
npm install

# Verify build works
npm run build
\`\`\`

### For Windows (Command Prompt or PowerShell):
\`\`\`batch
# Remove all node_modules and lock files
rmdir /s /q node_modules
del /q package-lock.json
del /q yarn.lock

# Clear npm cache completely
npm cache clean --force

# Verify versions
node -v    # Should be v20.x or higher
npm -v     # Should be v10.x or higher

# Fresh install
npm install

# Verify build works
npm run build
\`\`\`

## Local Development
\`\`\`bash
npm install
npm run dev
\`\`\`

## Build & Test Locally
\`\`\`bash
npm run build
npm start
\`\`\`

## Deploy to Vercel (CLI)
\`\`\`bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Deploy to production
vercel --prod
\`\`\`

## GitHub Actions Deployment
\`\`\`bash
# Push to main branch to trigger automatic deployment
git add .
git commit -m "Deploy to Vercel"
git push origin main
\`\`\`

## Environment Setup for GitHub Actions
\`\`\`bash
# Get Vercel Token
# 1. Go to https://vercel.com/account/tokens
# 2. Create new token
# 3. Add to GitHub Secrets as VERCEL_TOKEN

# Get Vercel IDs
# 1. Go to Vercel project settings
# 2. Copy Organization ID → VERCEL_ORG_ID
# 3. Copy Project ID → VERCEL_PROJECT_ID
\`\`\`

## Verify Deployment
\`\`\`bash
# Check build status
npm run build

# Test production build locally
npm run build && npm start

# Visit deployed URL
# https://<project-name>.vercel.app
\`\`\`

## Rollback to Previous Version
\`\`\`bash
# In Vercel Dashboard:
# 1. Go to Deployments
# 2. Find previous deployment
# 3. Click "Promote to Production"
\`\`\`

## Monitor Deployment
\`\`\`bash
# View logs in Vercel Dashboard
# Settings → Function Logs

# Or use Vercel CLI
vercel logs
\`\`\`
