# Clean Deployment Checklist for Neon Nexus City

## Pre-Deployment Cleanup (Choose your OS)

### For Linux/macOS:
\`\`\`bash
# Run the automated clean install script
chmod +x scripts/clean-install.sh
./scripts/clean-install.sh
\`\`\`

Or manually run these commands:
\`\`\`bash
# Remove all node_modules and lock files
rm -rf node_modules package-lock.json yarn.lock

# Clear npm cache completely
npm cache clean --force

# Verify versions
node -v    # Should be v20.x or higher
npm -v     # Should be v10.x or higher

# Fresh install
npm install

# Verify build works
npm run build
\`\`\`

### For Windows (PowerShell or Command Prompt):
```batch
# Run the automated clean install script
scripts\clean-install.bat
