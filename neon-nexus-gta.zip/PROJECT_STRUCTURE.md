# Neon Nexus City - Complete Project Structure

## Directory Layout

\`\`\`
neon-nexus-gta/
│
├── .github/
│   └── workflows/
│       └── deploy.yml                 # GitHub Actions CI/CD
│
├── app/
│   ├── page.tsx                       # Main game component (1000+ lines)
│   ├── layout.tsx                     # Root layout with fonts
│   └── globals.css                    # Global Tailwind styles
│
├── components/
│   ├── game-hud.tsx                   # HUD display component
│   ├── game-menu.tsx                  # Game menu component
│   ├── theme-provider.tsx             # Theme provider
│   └── ui/                            # shadcn/ui components (50+ files)
│       ├── button.tsx
│       ├── card.tsx
│       ├── dialog.tsx
│       └── ... (other UI components)
│
├── hooks/
│   ├── use-mobile.ts                  # Mobile detection hook
│   └── use-toast.ts                   # Toast notification hook
│
├── lib/
│   └── utils.ts                       # Utility functions (cn, etc)
│
├── public/
│   ├── placeholder.svg                # Placeholder images
│   ├── placeholder.jpg
│   └── placeholder-logo.png
│
├── styles/
│   └── globals.css                    # Additional global styles
│
├── .gitignore                         # Git ignore rules
├── components.json                    # shadcn/ui config
├── next.config.mjs                    # Next.js configuration
├── package.json                       # Dependencies & scripts
├── postcss.config.mjs                 # PostCSS configuration
├── tailwind.config.js                 # Tailwind CSS configuration
├── tsconfig.json                      # TypeScript configuration
│
├── DEPLOYMENT_GUIDE.md                # This deployment guide
├── DEPLOYMENT_COMMANDS.md             # Quick commands
└── PROJECT_STRUCTURE.md               # This file
\`\`\`

## Key Files Explained

### app/page.tsx (Main Game Engine)
- **Size**: ~1000 lines
- **Purpose**: Complete 3D game engine with Three.js
- **Features**:
  - Player movement and physics
  - NPC AI system
  - Vehicle driving mechanics
  - Combat and weapons system
  - Particle effects
  - Sound effects
  - HUD integration

### app/layout.tsx
- Root layout component
- Font imports (Geist, Geist Mono)
- Metadata configuration
- Provider setup

### components/game-hud.tsx
- Real-time HUD display
- Health, stamina, ammo bars
- Money and kill counter
- Threat level indicator
- Mission tracker

### components/game-menu.tsx
- Pause menu
- Game controls display
- Statistics panel
- Restart functionality

### Configuration Files

**next.config.mjs**
- React strict mode
- SWC minification
- Image optimization
- Build error handling

**postcss.config.mjs**
- Tailwind CSS v4 PostCSS plugin
- CSS processing pipeline

**tailwind.config.js**
- Custom theme colors
- Neon color scheme
- Animation configurations

**tsconfig.json**
- TypeScript strict mode
- Path aliases (@/)
- Module resolution

## Dependencies

### Production
- **next**: 16.0.0 - React framework
- **react**: 19.0.0 - UI library
- **three**: 0.180.0 - 3D graphics
- **cannon-es**: 0.20.0 - Physics engine
- **tailwindcss**: 4.1.9 - Styling
- **lucide-react**: 0.547.0 - Icons

### Development
- **typescript**: 5.0.0 - Type checking
- **@tailwindcss/postcss**: 4.1.9 - Tailwind PostCSS
- **postcss**: 8.5.6 - CSS processing

## Build Process

1. **Install**: `npm install` - Installs all dependencies
2. **Build**: `npm run build` - Compiles Next.js app
3. **Start**: `npm start` - Runs production server
4. **Dev**: `npm run dev` - Runs development server with hot reload

## Deployment Pipeline

\`\`\`
GitHub Push
    ↓
GitHub Actions Triggered
    ↓
npm install
    ↓
npm run build
    ↓
Vercel Deploy
    ↓
Live at vercel.app
\`\`\`

## File Sizes (Approximate)

- app/page.tsx: ~45 KB
- components/game-hud.tsx: ~8 KB
- components/game-menu.tsx: ~6 KB
- node_modules: ~500 MB
- Build output: ~2-3 MB

## Performance Metrics

- **Build Time**: 2-3 minutes
- **First Load**: ~3-5 seconds
- **Game FPS**: 60 FPS (on modern devices)
- **Bundle Size**: ~1.5 MB (gzipped)
