"use client"

import { useEffect, useRef } from "react"
import * as THREE from "three"
import GameHUD from "@/components/game-hud"
import GameMenu from "@/components/game-menu"

interface Player {
  position: THREE.Vector3
  velocity: THREE.Vector3
  health: number
  money: number
  ammo: number
  currentWeapon: number
  inVehicle: boolean
  stamina: number
  maxStamina: number
  kills: number
  deaths: number
  accuracy: number
  shotsFired: number
  shotsHit: number
  comboKills: number
  wantedLevel: number
  threatLevel: number
}

interface NPC {
  mesh: THREE.Mesh
  position: THREE.Vector3
  velocity: THREE.Vector3
  health: number
  maxHealth: number
  state: "patrol" | "chase" | "attack"
  target: THREE.Vector3
  detectionRange: number
  attackRange: number
  lastAttackTime: number
  isAlive: boolean
  isBoss: boolean
  lastShotTime: number
}

interface Vehicle {
  mesh: THREE.Mesh
  position: THREE.Vector3
  velocity: THREE.Vector3
  rotation: THREE.Euler
  speed: number
  maxSpeed: number
  acceleration: number
  occupied: boolean
  type: string
}

interface Bullet {
  position: THREE.Vector3
  velocity: THREE.Vector3
  mesh: THREE.Mesh
  damage: number
  lifetime: number
}

interface Particle {
  position: THREE.Vector3
  velocity: THREE.Vector3
  mesh: THREE.Mesh
  lifetime: number
  maxLifetime: number
  type: "blood" | "smoke" | "spark"
}

export default function GamePage() {
  const containerRef = useRef<HTMLDivElement>(null)
  const sceneRef = useRef<THREE.Scene | null>(null)
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const playerRef = useRef<Player>({
    position: new THREE.Vector3(0, 5, 0),
    velocity: new THREE.Vector3(0, 0, 0),
    health: 100,
    money: 5000,
    ammo: 150,
    currentWeapon: 0,
    inVehicle: false,
    stamina: 100,
    maxStamina: 100,
    kills: 0,
    deaths: 0,
    accuracy: 0,
    shotsFired: 0,
    shotsHit: 0,
    comboKills: 0,
    wantedLevel: 0,
    threatLevel: 0,
  })

  const npcsRef = useRef<NPC[]>([])
  const vehiclesRef = useRef<Vehicle[]>([])
  const bulletsRef = useRef<Bullet[]>([])
  const particlesRef = useRef<Particle[]>([])
  const keysRef = useRef<{ [key: string]: boolean }>({})
  const mouseRef = useRef({ x: 0, y: 0 })
  const cameraOffsetRef = useRef(new THREE.Vector3(0, 3, 8))
  const firstPersonRef = useRef(false)
  const gameStateRef = useRef({ paused: false, gameOver: false })
  const audioContextRef = useRef<AudioContext | null>(null)
  const lastMissionTimeRef = useRef(0)
  const currentMissionRef = useRef(0)

  useEffect(() => {
    if (!containerRef.current) return

    // Initialize Audio Context
    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()

    // Scene setup
    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0x0a0e27)
    scene.fog = new THREE.Fog(0x0a0e27, 200, 500)
    sceneRef.current = scene

    // Camera setup
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.copy(playerRef.current.position).add(cameraOffsetRef.current)
    cameraRef.current = camera

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFShadowMap
    containerRef.current.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x00ffff, 0.4)
    scene.add(ambientLight)

    const directionalLight = new THREE.DirectionalLight(0xff00ff, 0.8)
    directionalLight.position.set(50, 50, 50)
    directionalLight.castShadow = true
    directionalLight.shadow.mapSize.width = 2048
    directionalLight.shadow.mapSize.height = 2048
    directionalLight.shadow.camera.far = 200
    directionalLight.shadow.camera.left = -100
    directionalLight.shadow.camera.right = 100
    directionalLight.shadow.camera.top = 100
    directionalLight.shadow.camera.bottom = -100
    scene.add(directionalLight)

    // Point lights for neon effect
    const pointLight1 = new THREE.PointLight(0x00ffff, 1, 100)
    pointLight1.position.set(30, 20, 30)
    scene.add(pointLight1)

    const pointLight2 = new THREE.PointLight(0xff00ff, 1, 100)
    pointLight2.position.set(-30, 20, -30)
    scene.add(pointLight2)

    // Create ground with neon grid
    const groundGeometry = new THREE.PlaneGeometry(300, 300)
    const groundMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1f3a,
      metalness: 0.3,
      roughness: 0.7,
    })
    const ground = new THREE.Mesh(groundGeometry, groundMaterial)
    ground.rotation.x = -Math.PI / 2
    ground.receiveShadow = true
    scene.add(ground)

    // Add grid lines
    const gridHelper = new THREE.GridHelper(300, 30, 0x00ffff, 0xff00ff)
    gridHelper.position.y = 0.01
    scene.add(gridHelper)

    // Create player mesh
    const playerGeometry = new THREE.CapsuleGeometry(0.5, 2, 4, 8)
    const playerMaterial = new THREE.MeshStandardMaterial({
      color: 0x00ff00,
      emissive: 0x00ff00,
      emissiveIntensity: 0.3,
    })
    const playerMesh = new THREE.Mesh(playerGeometry, playerMaterial)
    playerMesh.position.copy(playerRef.current.position)
    playerMesh.castShadow = true
    playerMesh.receiveShadow = true
    scene.add(playerMesh)

    // Create buildings (skyscrapers)
    const buildingPositions = [
      { x: 40, z: 40 },
      { x: -40, z: 40 },
      { x: 40, z: -40 },
      { x: -40, z: -40 },
      { x: 60, z: 0 },
      { x: -60, z: 0 },
      { x: 0, z: 60 },
      { x: 0, z: -60 },
    ]

    buildingPositions.forEach((pos, idx) => {
      const height = 20 + Math.random() * 40
      const buildingGeometry = new THREE.BoxGeometry(15, height, 15)
      const buildingMaterial = new THREE.MeshStandardMaterial({
        color: idx % 2 === 0 ? 0x00ffff : 0xff00ff,
        emissive: idx % 2 === 0 ? 0x00ffff : 0xff00ff,
        emissiveIntensity: 0.2,
        metalness: 0.8,
        roughness: 0.2,
      })
      const building = new THREE.Mesh(buildingGeometry, buildingMaterial)
      building.position.set(pos.x, height / 2, pos.z)
      building.castShadow = true
      building.receiveShadow = true
      scene.add(building)
    })

    // Create NPCs
    const createNPC = (x: number, z: number, isBoss = false) => {
      const npcGeometry = new THREE.CapsuleGeometry(0.4, 1.8, 4, 8)
      const npcMaterial = new THREE.MeshStandardMaterial({
        color: isBoss ? 0xff0000 : 0xffff00,
        emissive: isBoss ? 0xff0000 : 0xffff00,
        emissiveIntensity: 0.5,
      })
      const npcMesh = new THREE.Mesh(npcGeometry, npcMaterial)
      npcMesh.position.set(x, 1, z)
      npcMesh.castShadow = true
      npcMesh.receiveShadow = true
      scene.add(npcMesh)

      const npc: NPC = {
        mesh: npcMesh,
        position: new THREE.Vector3(x, 1, z),
        velocity: new THREE.Vector3(0, 0, 0),
        health: isBoss ? 200 : 100,
        maxHealth: isBoss ? 200 : 100,
        state: "patrol",
        target: new THREE.Vector3(Math.random() * 100 - 50, 1, Math.random() * 100 - 50),
        detectionRange: isBoss ? 60 : 40,
        attackRange: isBoss ? 30 : 20,
        lastAttackTime: 0,
        isAlive: true,
        isBoss: isBoss,
        lastShotTime: 0,
      }
      npcsRef.current.push(npc)
    }

    // Spawn NPCs
    for (let i = 0; i < 12; i++) {
      const isBoss = i < 2
      createNPC(Math.random() * 100 - 50, Math.random() * 100 - 50, isBoss)
    }

    // Create vehicles
    const createVehicle = (x: number, z: number, type: string) => {
      const vehicleGeometry = new THREE.BoxGeometry(2, 1.5, 4)
      const vehicleMaterial = new THREE.MeshStandardMaterial({
        color: 0xff6600,
        metalness: 0.6,
        roughness: 0.4,
      })
      const vehicleMesh = new THREE.Mesh(vehicleGeometry, vehicleMaterial)
      vehicleMesh.position.set(x, 0.75, z)
      vehicleMesh.castShadow = true
      vehicleMesh.receiveShadow = true
      scene.add(vehicleMesh)

      const vehicle: Vehicle = {
        mesh: vehicleMesh,
        position: new THREE.Vector3(x, 0.75, z),
        velocity: new THREE.Vector3(0, 0, 0),
        rotation: new THREE.Euler(0, 0, 0),
        speed: 0,
        maxSpeed: 0.5,
        acceleration: 0.02,
        occupied: false,
        type: type,
      }
      vehiclesRef.current.push(vehicle)
    }

    createVehicle(20, 20, "car")
    createVehicle(-20, 20, "car")
    createVehicle(20, -20, "car")
    createVehicle(-20, -20, "car")

    // Sound effect generator
    const playSound = (type: string, frequency = 440, duration = 0.1) => {
      if (!audioContextRef.current) return
      const ctx = audioContextRef.current
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)

      osc.frequency.value = frequency
      gain.gain.setValueAtTime(0.1, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + duration)
      osc.start(ctx.currentTime)
      osc.stop(ctx.currentTime + duration)
    }

    // Create particle effect
    const createParticles = (position: THREE.Vector3, type: "blood" | "smoke" | "spark", count = 10) => {
      for (let i = 0; i < count; i++) {
        const particleGeometry = new THREE.SphereGeometry(0.1, 4, 4)
        let particleMaterial: THREE.Material
        let color = 0xff0000

        if (type === "blood") {
          color = 0xff0000
          particleMaterial = new THREE.MeshStandardMaterial({ color })
        } else if (type === "smoke") {
          color = 0x888888
          particleMaterial = new THREE.MeshStandardMaterial({ color, transparent: true, opacity: 0.6 })
        } else {
          color = 0xffff00
          particleMaterial = new THREE.MeshStandardMaterial({ color, emissive: color })
        }

        const particleMesh = new THREE.Mesh(particleGeometry, particleMaterial)
        particleMesh.position.copy(position)
        scene.add(particleMesh)

        const particle: Particle = {
          position: position.clone(),
          velocity: new THREE.Vector3((Math.random() - 0.5) * 0.3, Math.random() * 0.3, (Math.random() - 0.5) * 0.3),
          mesh: particleMesh,
          lifetime: 0,
          maxLifetime: 1,
          type: type,
        }
        particlesRef.current.push(particle)
      }
    }

    // Keyboard and mouse events
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = true
      if (e.key === "e" || e.key === "E") {
        vehiclesRef.current.forEach((vehicle) => {
          const distance = playerRef.current.position.distanceTo(vehicle.position)
          if (distance < 5) {
            playerRef.current.inVehicle = !playerRef.current.inVehicle
            vehicle.occupied = playerRef.current.inVehicle
          }
        })
      }
      if (e.key === "c" || e.key === "C") {
        firstPersonRef.current = !firstPersonRef.current
      }
      if (e.key === "m" || e.key === "M") {
        currentMissionRef.current = (currentMissionRef.current + 1) % 3
      }
      if (e.key === "1") playerRef.current.currentWeapon = 0
      if (e.key === "2") playerRef.current.currentWeapon = 1
      if (e.key === "3") playerRef.current.currentWeapon = 2
      if (e.key === " ") {
        if (!playerRef.current.inVehicle && playerRef.current.velocity.y === 0) {
          playerRef.current.velocity.y = 0.3
        }
      }
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.x = (e.clientX / window.innerWidth) * 2 - 1
      mouseRef.current.y = -(e.clientY / window.innerHeight) * 2 + 1
    }

    const handleMouseClick = () => {
      if (gameStateRef.current.paused || gameStateRef.current.gameOver) return

      const weaponDamages = [35, 60, 60]
      const weaponAmmos = [1, 2, 3]
      const damage = weaponDamages[playerRef.current.currentWeapon]
      const ammoUsed = weaponAmmos[playerRef.current.currentWeapon]

      if (playerRef.current.ammo >= ammoUsed) {
        playerRef.current.ammo -= ammoUsed
        playerRef.current.shotsFired++
        playSound("shoot", 800, 0.1)

        const raycaster = new THREE.Raycaster()
        raycaster.setFromCamera(mouseRef.current, camera)

        npcsRef.current.forEach((npc) => {
          if (!npc.isAlive) return
          const distance = raycaster.ray.distanceToPoint(npc.position)
          if (distance < 1) {
            npc.health -= damage * (playerRef.current.comboKills > 0 ? 1 + playerRef.current.comboKills * 0.5 : 1)
            playerRef.current.shotsHit++
            createParticles(npc.position, "blood", 15)
            playSound("hit", 600, 0.05)

            if (npc.health <= 0) {
              npc.isAlive = false
              playerRef.current.kills++
              playerRef.current.comboKills++
              playerRef.current.money += 100
              createParticles(npc.position, "spark", 20)
              playSound("kill", 1200, 0.2)
              scene.remove(npc.mesh)
            }
          }
        })
      }
    }

    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    window.addEventListener("mousemove", handleMouseMove)
    window.addEventListener("click", handleMouseClick)

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate)

      if (gameStateRef.current.paused) {
        renderer.render(scene, camera)
        return
      }

      // Player movement
      if (!playerRef.current.inVehicle) {
        const moveSpeed = keysRef.current["shift"] ? 0.3 : 0.15
        const direction = new THREE.Vector3()

        if (keysRef.current["w"]) direction.z -= moveSpeed
        if (keysRef.current["s"]) direction.z += moveSpeed
        if (keysRef.current["a"]) direction.x -= moveSpeed
        if (keysRef.current["d"]) direction.x += moveSpeed

        playerRef.current.velocity.x = direction.x
        playerRef.current.velocity.z = direction.z

        if (keysRef.current["shift"] && direction.length() > 0) {
          playerRef.current.stamina = Math.max(0, playerRef.current.stamina - 1)
        } else {
          playerRef.current.stamina = Math.min(playerRef.current.maxStamina, playerRef.current.stamina + 0.5)
        }
      } else {
        // Vehicle movement
        const vehicle = vehiclesRef.current.find((v) => v.occupied)
        if (vehicle) {
          if (keysRef.current["w"]) vehicle.speed = Math.min(vehicle.maxSpeed, vehicle.speed + vehicle.acceleration)
          if (keysRef.current["s"])
            vehicle.speed = Math.max(-vehicle.maxSpeed / 2, vehicle.speed - vehicle.acceleration)
          if (keysRef.current["a"]) vehicle.rotation.y += 0.05
          if (keysRef.current["d"]) vehicle.rotation.y -= 0.05

          vehicle.velocity.x = Math.sin(vehicle.rotation.y) * vehicle.speed
          vehicle.velocity.z = Math.cos(vehicle.rotation.y) * vehicle.speed

          vehicle.position.x += vehicle.velocity.x
          vehicle.position.z += vehicle.velocity.z
          vehicle.mesh.position.copy(vehicle.position)
          vehicle.mesh.rotation.copy(vehicle.rotation)

          playerRef.current.position.copy(vehicle.position)
          playerRef.current.velocity.copy(vehicle.velocity)
        }
      }

      // Gravity
      playerRef.current.velocity.y -= 0.01
      playerRef.current.position.y += playerRef.current.velocity.y

      if (playerRef.current.position.y < 1) {
        playerRef.current.position.y = 1
        playerRef.current.velocity.y = 0
      }

      // Map boundaries
      playerRef.current.position.x = Math.max(-150, Math.min(150, playerRef.current.position.x))
      playerRef.current.position.z = Math.max(-150, Math.min(150, playerRef.current.position.z))

      playerMesh.position.copy(playerRef.current.position)

      // NPC AI
      npcsRef.current.forEach((npc) => {
        if (!npc.isAlive) return

        const distanceToPlayer = npc.position.distanceTo(playerRef.current.position)

        if (distanceToPlayer < npc.detectionRange) {
          npc.state = "chase"
          npc.target.copy(playerRef.current.position)
        } else if (distanceToPlayer > npc.detectionRange * 1.5) {
          npc.state = "patrol"
          if (Math.random() < 0.01) {
            npc.target.set(Math.random() * 100 - 50, 1, Math.random() * 100 - 50)
          }
        }

        if (npc.state === "patrol") {
          const direction = npc.target.clone().sub(npc.position).normalize()
          npc.velocity.x = direction.x * 0.1
          npc.velocity.z = direction.z * 0.1
        } else if (npc.state === "chase") {
          const direction = playerRef.current.position.clone().sub(npc.position).normalize()
          npc.velocity.x = direction.x * 0.15
          npc.velocity.z = direction.z * 0.15

          if (distanceToPlayer < npc.attackRange && Date.now() - npc.lastAttackTime > 1000) {
            playerRef.current.health -= npc.isBoss ? 15 : 10
            playerRef.current.wantedLevel = Math.min(5, playerRef.current.wantedLevel + 0.5)
            npc.lastAttackTime = Date.now()
            playSound("attack", 300, 0.1)
          }
        }

        npc.position.x += npc.velocity.x
        npc.position.z += npc.velocity.z
        npc.mesh.position.copy(npc.position)

        // NPC shooting
        if (npc.state === "chase" && Date.now() - npc.lastShotTime > 1500) {
          const direction = playerRef.current.position.clone().sub(npc.position).normalize()
          const bulletVelocity = direction.multiplyScalar(0.5)
          const bullet: Bullet = {
            position: npc.position.clone(),
            velocity: bulletVelocity,
            mesh: new THREE.Mesh(
              new THREE.SphereGeometry(0.1, 4, 4),
              new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0xff0000 }),
            ),
            damage: npc.isBoss ? 20 : 10,
            lifetime: 0,
          }
          scene.add(bullet.mesh)
          bulletsRef.current.push(bullet)
          npc.lastShotTime = Date.now()
        }
      })

      // Update bullets
      bulletsRef.current = bulletsRef.current.filter((bullet) => {
        bullet.position.add(bullet.velocity)
        bullet.mesh.position.copy(bullet.position)
        bullet.lifetime++

        if (bullet.lifetime > 300) {
          scene.remove(bullet.mesh)
          return false
        }

        const distanceToPlayer = bullet.position.distanceTo(playerRef.current.position)
        if (distanceToPlayer < 1) {
          playerRef.current.health -= bullet.damage
          createParticles(bullet.position, "spark", 10)
          scene.remove(bullet.mesh)
          return false
        }

        return true
      })

      // Update particles
      particlesRef.current = particlesRef.current.filter((particle) => {
        particle.lifetime += 0.016
        particle.velocity.y -= 0.01
        particle.position.add(particle.velocity)
        particle.mesh.position.copy(particle.position)

        if (particle.type === "smoke" || particle.type === "blood") {
          const opacity = 1 - particle.lifetime / particle.maxLifetime
          ;(particle.mesh.material as THREE.MeshStandardMaterial).opacity = opacity
        }

        if (particle.lifetime > particle.maxLifetime) {
          scene.remove(particle.mesh)
          return false
        }

        return true
      })

      // Update threat level
      playerRef.current.threatLevel = npcsRef.current.filter((n) => n.isAlive && n.state === "chase").length

      // Combo kill timeout
      if (Date.now() - lastMissionTimeRef.current > 5000) {
        playerRef.current.comboKills = 0
      }

      // Camera update
      if (firstPersonRef.current) {
        camera.position.copy(playerRef.current.position).add(new THREE.Vector3(0, 1.6, 0))
        camera.lookAt(playerRef.current.position.clone().add(new THREE.Vector3(0, 0, -1)))
      } else {
        const targetCameraPos = playerRef.current.position.clone().add(cameraOffsetRef.current)
        camera.position.lerp(targetCameraPos, 0.1)
        camera.lookAt(playerRef.current.position.clone().add(new THREE.Vector3(0, 1, 0)))
      }

      // Game over check
      if (playerRef.current.health <= 0) {
        gameStateRef.current.gameOver = true
        playerRef.current.deaths++
      }

      renderer.render(scene, camera)
    }

    animate()

    // Handle window resize
    const handleResize = () => {
      const width = window.innerWidth
      const height = window.innerHeight
      camera.aspect = width / height
      camera.updateProjectionMatrix()
      renderer.setSize(width, height)
    }

    window.addEventListener("resize", handleResize)

    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
      window.removeEventListener("mousemove", handleMouseMove)
      window.removeEventListener("click", handleMouseClick)
      window.removeEventListener("resize", handleResize)
      containerRef.current?.removeChild(renderer.domElement)
    }
  }, [])

  return (
    <div className="w-full h-screen overflow-hidden bg-black">
      <div ref={containerRef} className="w-full h-full" />
      <GameHUD player={playerRef.current} threatLevel={playerRef.current.threatLevel} />
      <GameMenu
        onPause={(paused) => {
          gameStateRef.current.paused = paused
        }}
      />
    </div>
  )
}
