export { default } from "@/src/components/game-hud"
