export { default } from "@/src/components/game-menu"
