#!/bin/bash
# Clean installation script for Linux/macOS

echo "🧹 Starting clean installation process..."
echo ""

# Step 1: Remove node_modules and lock files
echo "📦 Removing node_modules and package-lock.json..."
rm -rf node_modules
rm -f package-lock.json
rm -f yarn.lock
echo "✅ Removed node_modules and lock files"
echo ""

# Step 2: Clear npm cache
echo "🗑️  Clearing npm cache..."
npm cache clean --force
echo "✅ npm cache cleared"
echo ""

# Step 3: Verify Node.js and npm versions
echo "🔍 Verifying Node.js and npm versions..."
echo "Node.js version:"
node -v
echo "npm version:"
npm -v
echo ""

# Step 4: Install dependencies
echo "📥 Installing dependencies..."
npm install
echo "✅ Dependencies installed"
echo ""

# Step 5: Verify build
echo "🔨 Building project..."
npm run build
echo "✅ Build successful"
echo ""

echo "🎉 Clean installation complete! Ready for deployment."
